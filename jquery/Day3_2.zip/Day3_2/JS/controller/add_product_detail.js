import Product from "../model/product.js";
import CustomerService from "../service/Customer_service.js";

$(document).ready(function () {
    $(".registerbtn1").click(
        function () {
            let p_name = $("#txt_pname").val();
            let p_brand = $("#txt_bname").val();
            let p_price = $("#price").val();
            let p_avail = "";
            let p_desc = $("#desc").val();
            let p_type = $("#fil").val();
            if ($("#yes").is(':checked')) {
                p_avail = $("#yes").val();
                // console.log($("#male").val());
            }
            else if ($("#no").is(':checked')) {
                p_avail = $("#female").val();
                // console.log($("#female").val());
            }
            let product = new Product();
            product.productName = p_name;    // calling the setter property, not variable(_customerName)
            product.brandName = p_brand;
            product.productPrice = c_dob;
            product.cont = c_contact;
            product.gender = c_gender;
            product.email = c_email;
            product.password = c_pass;
        })
})