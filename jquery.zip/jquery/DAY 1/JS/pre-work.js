// Callback Function

// abc();
// function xyz(( => {
//     console.log("ABC");
// }
// function xyz(() =>
//     console.log("xyz");
// )
// xyz();
